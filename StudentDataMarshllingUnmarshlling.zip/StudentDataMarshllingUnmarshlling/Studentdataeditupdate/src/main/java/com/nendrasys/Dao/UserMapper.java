package com.nendrasys.Dao;

import com.nendrasys.Model.Studentinfo;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

public class UserMapper implements RowMapper<Studentinfo>{

    @Override
    public Studentinfo mapRow(ResultSet rs, int i) throws SQLException {
        Studentinfo s = new Studentinfo();
        s.setId(rs.getInt("id"));
        s.setName(rs.getString("name"));
        s.setAge(rs.getInt("age"));
        s.setCountry(rs.getString("country"));
        return s;
    }

}

